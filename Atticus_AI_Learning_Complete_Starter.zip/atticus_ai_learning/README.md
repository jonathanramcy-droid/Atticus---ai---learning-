# Atticus AI Learning — starter website

A responsive school-learning website with:
- AI tutor for mathematics, languages, sciences, ICT, humanities, and other subjects
- Detailed explanations, worked examples, and study-note prompts
- Scientific calculator with degree/radian mode, trig functions, logarithms, roots, powers, factorial, π, e, and Ans
- Server-side AI connection so the API key is not exposed in the browser

## Important
This is a working starter project, not a published app or a guarantee that every AI answer is correct. AI can make mistakes. Verify important answers with your textbook, teacher, and reliable references.

## Run it on a computer
1. Install Node.js 18 or newer.
2. Open a terminal in this project folder.
3. Set `OPENAI_API_KEY` in your terminal/server environment. Do not put the key in `public/index.html`, upload it to GitHub, or share it.
   - macOS/Linux: `export OPENAI_API_KEY="your_private_key"`
   - Windows PowerShell: `$env:OPENAI_API_KEY="your_private_key"`
4. Optional: set `OPENAI_MODEL` to a model available to your API account.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The AI endpoint requires internet access and an OpenAI API account with API billing/access configured. API usage may cost money. The calculator and static website can be used without an API key, but AI answers will not work until configured.

## Publish the website
Deploy this Node.js project to a hosting provider that supports Node.js. Configure `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in the host's private environment-variable settings. Set the start command to `npm start`. Do not publish your secret key or commit a real `.env` file. A static-only host cannot run this backend unless you deploy the API endpoint separately as a serverless function.

## Android app
The website can later be packaged into an Android app using a trusted WebView/PWA workflow and tested on real devices. The AI tutor needs internet and a configured backend; the calculator can work offline.

## Recommended before public launch
Add rate limiting, abuse protection, a privacy notice, and tests. Add trusted citations/search if you need current facts. Never promise perfect accuracy.
