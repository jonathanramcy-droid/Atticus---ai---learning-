// Atticus AI Learning server. Keep your API key on the server; never put it in public/index.html.
const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4.1-mini';
const root = path.join(__dirname, 'public');
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.json':'application/json','.svg':'image/svg+xml'};
function send(res, code, obj){res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
const server = http.createServer(async (req,res)=>{
  if(req.method==='POST' && req.url==='/api/ask'){
    if(!API_KEY) return send(res,503,{error:'AI is not configured yet. Add OPENAI_API_KEY to your server environment.'});
    let body='';
    req.on('data',chunk=>{body+=chunk;if(body.length>50000){req.destroy();}});
    req.on('end',async()=>{
      try{
        const data=JSON.parse(body||'{}');
        const question=String(data.question||'').trim().slice(0,12000);
        const subject=String(data.subject||'General').slice(0,100);
        const level=String(data.level||'High school').slice(0,100);
        if(!question)return send(res,400,{error:'Please enter a question.'});
        const response=await fetch('https://api.openai.com/v1/responses',{
          method:'POST',
          headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},
          body:JSON.stringify({
            model:MODEL,
            instructions:`You are Atticus AI Learning, a careful and supportive school tutor. Help with all school subjects. Audience level: ${level}. Subject: ${subject}. Answer accurately and in detail, using simple language appropriate to the level. For calculations, show steps and check the result. For science, explain concepts and distinguish established facts from uncertainty. If the question is ambiguous, state your assumption or ask a concise clarification. Never invent sources, facts, or citations. When useful, structure the answer with: direct answer, explanation, worked example, key points, and a short self-check question. If you are uncertain, say so clearly and suggest how to verify. Support learning rather than just copying.`,
            input:question
          })
        });
        const payload=await response.json();
        if(!response.ok)return send(res,response.status,{error:payload.error?.message||'AI provider request failed.'});
        const answer=(payload.output||[]).flatMap(item=>item.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n');
        if(!answer)return send(res,502,{error:'The AI returned no text. Please try again.'});
        send(res,200,{answer});
      }catch(e){send(res,500,{error:'Could not process the request. Check the server logs and try again.'});}
    });
    return;
  }
  if(req.method!=='GET' && req.method!=='HEAD'){res.writeHead(405);return res.end('Method Not Allowed');}
  let pathname=decodeURIComponent((req.url||'/').split('?')[0]);
  if(pathname==='/')pathname='/index.html';
  const file=path.resolve(root,'.'+pathname);
  if(!file.startsWith(root+path.sep)){res.writeHead(403);return res.end('Forbidden');}
  fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end('Not Found');}
    res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});
    if(req.method==='HEAD')return res.end();res.end(data);
  });
});
server.listen(PORT,()=>console.log(`Atticus AI Learning running on http://localhost:${PORT}`));
